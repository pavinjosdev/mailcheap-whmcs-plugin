<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}


require_once 'lib/Transport.php';
require_once 'lib/Mailcheap.php';


/**
 * Define module related meta data.
 *
 * Values returned here are used to determine module related abilities and
 * settings.
 *
 * @see https://developers.whmcs.com/provisioning-modules/meta-data-params/
 *
 * @return array
 */
function mailcheap_MetaData()
{
    return array(
        'DisplayName' => 'MailCheap',
        'APIVersion' => '1.1', // Use API Version 1.1
        'RequiresServer' => true, // Set true if module requires a server to work
        'DefaultNonSSLPort' => '1111', // Default Non-SSL Connection Port
        'DefaultSSLPort' => '1112', // Default SSL Connection Port
    );
}

/**
 * Define product configuration options.
 *
 * The values you return here define the configuration options that are
 * presented to a user when configuring a product for use with the module. These
 * values are then made available in all module function calls with the key name
 * configoptionX - with X being the index number of the field from 1 to 24.
 *
 * You can specify up to 24 parameters, with field types:
 * * text
 * * password
 * * yesno
 * * dropdown
 * * radio
 * * textarea
 *
 * Examples of each and their possible configuration parameters are provided in
 * this sample function.
 *
 * @see https://developers.whmcs.com/provisioning-modules/config-options/
 *
 * @return array
 */
function mailcheap_ConfigOptions()
{
    return array(
        // a text field type allows for single line text input
        'quota' => array(
            'Type' => 'text',
            'Size' => '25',
            'Default' => '500',
            'Description' => 'Storage quota',
        ),
        'quotaDomains' => array(
             'Type' => 'text',
             'Size' => '25',
             'Default' => '5',
             'Description' => 'Quota domains',
         ),
        'quotaMailboxes' => array(
             'Type' => 'text',
             'Size' => '25',
             'Default' => '5',
             'Description' => 'Quota mailboxes',
         ),
        'quotaAliases' => array(
             'Type' => 'text',
             'Size' => '25',
             'Default' => '5',
             'Description' => 'Quota aliases',
         ),
         'quotaDomainAliases' => array(
             'Type' => 'text',
             'Size' => '25',
             'Default' => '5',
             'Description' => 'Quota domain aliases',
         )
    );
}

/**
 * Provision a new instance of a product/service.
 *
 * Attempt to provision a new instance of a given product/service. This is
 * called any time provisioning is requested inside of WHMCS. Depending upon the
 * configuration, this can be any of:
 * * When a new order is placed
 * * When an invoice for a new order is paid
 * * Upon manual request by an admin user
 *
 * @param array $params common module parameters
 *
 * @see https://developers.whmcs.com/provisioning-modules/module-parameters/
 *
 * @return string "success" or an error message
 */
function mailcheap_CreateAccount(array $params)
{
    try {
        $client = new \MailCheap\MailCheap($params);
        $auth = $client->auth($params);
        if( ( !$auth->error) &&  $auth->auth->status == 'success' ){
            $token = $auth->auth->auth_token;
            $request = $client->createUser($params,$token);
            if( $request->error ){
                throw new Exception($request->message);
            }
        }else{
            throw new Exception(json_encode($auth));
        }

    } catch (Exception $e) {
        // Record the error in WHMCS's module log.
        logModuleCall(
            'MailCheap',
            __FUNCTION__,
            $params,
            $e->getMessage()
        );

        return $e->getMessage();
    }

    return 'success';
}

/**
 * Suspend an instance of a product/service.
 *
 * Called when a suspension is requested. This is invoked automatically by WHMCS
 * when a product becomes overdue on payment or can be called manually by admin
 * user.
 *
 * @param array $params common module parameters
 *
 * @see https://developers.whmcs.com/provisioning-modules/module-parameters/
 *
 * @return string "success" or an error message
 */
function mailcheap_SuspendAccount(array $params)
{
    try {
         $client = new \MailCheap\MailCheap($params);
         $auth = $client->auth($params);
         if( ( !$auth->error) &&  $auth->auth->status == 'success' ){
             $token = $auth->auth->auth_token;
             $request = $client->disableUser($params['username'],$token);
             if( $request->error ){
                 throw new Exception($request->message);
             }
         }else{
             throw new Exception(json_encode($auth));
         }

     } catch (Exception $e) {
         // Record the error in WHMCS's module log.
         logModuleCall(
             'MailCheap',
             __FUNCTION__,
             $params,
             $e->getMessage()
         );

         return $e->getMessage();
     }

     return 'success';

}

/**
 * Un-suspend instance of a product/service.
 *
 * Called when an un-suspension is requested. This is invoked
 * automatically upon payment of an overdue invoice for a product, or
 * can be called manually by admin user.
 *
 * @param array $params common module parameters
 *
 * @see https://developers.whmcs.com/provisioning-modules/module-parameters/
 *
 * @return string "success" or an error message
 */
function mailcheap_UnsuspendAccount(array $params)
{
    try {
          $client = new \MailCheap\MailCheap($params);
          $auth = $client->auth($params);
          if( ( !$auth->error) &&  $auth->auth->status == 'success' ){
              $token = $auth->auth->auth_token;
              $request = $client->enableUser($params['username'],$token);
              if( $request->error ){
                  throw new Exception($request->message);
              }
          }else{
              throw new Exception(json_encode($auth));
          }

      } catch (Exception $e) {
          // Record the error in WHMCS's module log.
          logModuleCall(
              'MailCheap',
              __FUNCTION__,
              $params,
              $e->getMessage()
          );

          return $e->getMessage();
      }

      return 'success';

}

/**
 * Terminate instance of a product/service.
 *
 * Called when a termination is requested. This can be invoked automatically for
 * overdue products if enabled, or requested manually by an admin user.
 *
 * @param array $params common module parameters
 *
 * @see https://developers.whmcs.com/provisioning-modules/module-parameters/
 *
 * @return string "success" or an error message
 */
function mailcheap_TerminateAccount(array $params)
{
    try {
          $client = new \MailCheap\MailCheap($params);
          $auth = $client->auth($params);
          if( ( !$auth->error) &&  $auth->auth->status == 'success' ){
              $token = $auth->auth->auth_token;
              $request = $client->deleteUser($params['username'],$token);
              if( $request->error ){
                  throw new Exception($request->message);
              }
          }else{
              throw new Exception(json_encode($auth));
          }

      } catch (Exception $e) {
          // Record the error in WHMCS's module log.
          logModuleCall(
              'MailCheap',
              __FUNCTION__,
              $params,
              $e->getMessage()
          );

          return $e->getMessage();
      }

      return 'success';

}

/**
 * Test connection with the given server parameters.
 *
 * Allows an admin user to verify that an API connection can be
 * successfully made with the given configuration parameters for a
 * server.
 *
 * When defined in a module, a Test Connection button will appear
 * alongside the Server Type dropdown when adding or editing an
 * existing server.
 *
 * @param array $params common module parameters
 *
 * @see https://developers.whmcs.com/provisioning-modules/module-parameters/
 *
 * @return array
 */
function mailcheap_TestConnection(array $params)
{
    try {
        $client = new \MailCheap\MailCheap($params);
        $auth = $client->auth($params);
        if( $auth->auth->status == 'success' ){
            $success = true;
            $errorMsg = '';
        }else{
            $success = false;
            $errorMsg = $auth->auth->message;
        }
    } catch (Exception $e) {
        // Record the error in WHMCS's module log.
        logModuleCall(
            'mailcheap',
            __FUNCTION__,
            $params,
            $e->getMessage()
        );

        $success = false;
        $errorMsg = $e->getMessage();
    }

    return array(
        'success' => $success,
        'error' => $errorMsg,
    );
}

/**
 * Additional actions an admin user can invoke.
 *
 * Define additional actions that an admin user can perform for an
 * instance of a product/service.
 *
 * @see mailcheap_buttonOneFunction()
 *
 * @return array
 */
function mailcheap_AdminCustomButtonArray()
{
    return array(
    );
}

/**
 * Additional actions a client user can invoke.
 *
 * Define additional actions a client user can perform for an instance of a
 * product/service.
 *
 * Any actions you define here will be automatically displayed in the available
 * list of actions within the client area.
 *
 * @return array
 */
function mailcheap_ClientAreaCustomButtonArray()
{
    return array(
    );
}


/**
 * Admin services tab additional fields.
 *
 * Define additional rows and fields to be displayed in the admin area service
 * information and management page within the clients profile.
 *
 * Supports an unlimited number of additional field labels and content of any
 * type to output.
 *
 * @param array $params common module parameters
 *
 * @see https://developers.whmcs.com/provisioning-modules/module-parameters/
 * @see mailcheap_AdminServicesTabFieldsSave()
 *
 * @return array
 */
function mailcheap_AdminServicesTabFields(array $params)
{
    try {
        // Call the service's function, using the values provided by WHMCS in
        // `$params`.
        $response = array();

        // Return an array based on the function's response.
        return array(
        );
    } catch (Exception $e) {
        // Record the error in WHMCS's module log.
        logModuleCall(
            'provisioningmodule',
            __FUNCTION__,
            $params,
            $e->getMessage(),
            $e->getTraceAsString()
        );

        // In an error condition, simply return no additional fields to display.
    }

    return array();
}

/**
 * Execute actions upon save of an instance of a product/service.
 *
 * Use to perform any required actions upon the submission of the admin area
 * product management form.
 *
 * It can also be used in conjunction with the AdminServicesTabFields function
 * to handle values submitted in any custom fields which is demonstrated here.
 *
 * @param array $params common module parameters
 *
 * @see https://developers.whmcs.com/provisioning-modules/module-parameters/
 * @see mailcheap_AdminServicesTabFields()
 */
function mailcheap_AdminServicesTabFieldsSave(array $params)
{
}

/**
 * Client area output logic handling.
 *
 * This function is used to define module specific client area output. It should
 * return an array consisting of a template file and optional additional
 * template variables to make available to that template.
 *
 * The template file you return can be one of two types:
 *
 * * tabOverviewModuleOutputTemplate - The output of the template provided here
 *   will be displayed as part of the default product/service client area
 *   product overview page.
 *
 * * tabOverviewReplacementTemplate - Alternatively using this option allows you
 *   to entirely take control of the product/service overview page within the
 *   client area.
 *
 * Whichever option you choose, extra template variables are defined in the same
 * way. This demonstrates the use of the full replacement.
 *
 * Please Note: Using tabOverviewReplacementTemplate means you should display
 * the standard information such as pricing and billing details in your custom
 * template or they will not be visible to the end user.
 *
 * @param array $params common module parameters
 *
 * @see https://developers.whmcs.com/provisioning-modules/module-parameters/
 *
 * @return array
 */



function mailcheap_ClientArea(array $params)
{
    // Determine the requested action and set service call parameters based on
    // the action.
    $requestedAction = isset($_REQUEST['customAction']) ? $_REQUEST['customAction'] : '';

    if ($requestedAction == 'manage') {
        $serviceAction = 'get_usage';
        $templateFile = 'templates/manage.tpl';
    } else {
        $serviceAction = 'get_stats';
        $templateFile = 'templates/overview.tpl';
    }

    try {
        // Call the service's function based on the request action, using the
        // values provided by WHMCS in `$params`.
        $response = array();

        $extraVariable1 = 'abc';
        $extraVariable2 = '123';

        return array(
            'tabOverviewReplacementTemplate' => $templateFile,
            'templateVariables' => array(
                'extraVariable1' => $extraVariable1,
                'extraVariable2' => $extraVariable2,
            ),
        );
    } catch (Exception $e) {
        // Record the error in WHMCS's module log.
        logModuleCall(
            'provisioningmodule',
            __FUNCTION__,
            $params,
            $e->getMessage(),
            $e->getTraceAsString()
        );

        // In an error condition, display an error page.
        return array(
            'tabOverviewReplacementTemplate' => 'error.tpl',
            'templateVariables' => array(
                'usefulErrorHelper' => $e->getMessage(),
            ),
        );
    }
}

