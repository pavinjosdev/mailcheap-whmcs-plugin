<?php

namespace MailCheap;

class Transport{

    public function __construct(){
        $this->ch = curl_init();
        //curl_setopt($this->ch, CURLOPT_USERPWD, $this->username . ":" . $this->password);
        //curl_setopt($this->ch, CURLOPT_HTTPHEADER, [ "Authorization: Basic ". $this->token,  'Content-Type: application/json' ]);
        curl_setopt($this->ch, CURLOPT_HTTPHEADER, [ 'Content-Type: application/json', 'Accept: application/json' ]);
        curl_setopt($this->ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);
        
    }

    public function request( $method, $command, $post = [], $get = [] ){
        $url = $this->url . $command;
        if( $get ){
            foreach( $get as $k => $v ){
                $url .= "&{$k}={$v}";
            }
        }
        curl_setopt($this->ch,CURLOPT_URL, $url);
        curl_setopt($this->ch,CURLOPT_POST, false );
        if( $this->token ){
            curl_setopt($this->ch, CURLOPT_HTTPHEADER, [ "Authorization: Basic " . base64_encode("{$this->username}:{$this->token}"),  'Content-Type: application/json' ]);
        }
        switch( $method ){
            case 'post':
                curl_setopt($this->ch,CURLOPT_POST, count($post));
                curl_setopt($this->ch,CURLOPT_POSTFIELDS, json_encode( $post ));
                break;
            case 'get':
                break;
            case 'delete':
                curl_setopt($this->ch,CURLOPT_POSTFIELDS, json_encode( $post ));
                curl_setopt($this->ch, CURLOPT_CUSTOMREQUEST, "DELETE");
                break;
            case 'put':
                curl_setopt($this->ch,CURLOPT_POSTFIELDS, json_encode( $post ));
                curl_setopt($this->ch, CURLOPT_CUSTOMREQUEST, "PUT");
                break;
            case 'patch':
                curl_setopt($this->ch,CURLOPT_POSTFIELDS, json_encode( $post ));
                curl_setopt($this->ch, CURLOPT_CUSTOMREQUEST, "PATCH");
                break;

        }
        $result = curl_exec($this->ch);
        $info = curl_getinfo( $this->ch );
        return json_decode( $result );
    }

    public function __destroy(){
        curl_close($this->ch);
    }

}

