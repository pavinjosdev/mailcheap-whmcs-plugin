<?php

namespace MailCheap;

class MailCheap extends Transport{

    protected $url;
    protected $token;
    protected $username;

    /*
    *
    * Initialize connection
    * @param array $params
    */

    public function __construct(array $params){
        if( $params['serversecure'] ){
            $this->url = 'https://' . $params['serverhostname'];
        }else{
            $this->url = 'http://' . $params['serverhostname'];
        }
        parent::__construct();
    }

    /*
    *
    * Authentication POST request --> this is used to get auth_token (authorization token to be used in subsequent calls - valid for 24 hours)
    *
    */

    public function auth($params){
        $this->username = $params['serverusername'];
        $request = $this->request( 'post', '/api/v1/auth/',[ 'username' => $params['serverusername'],'password' => $params['serverpassword'] ] );
        return $request;

    }

    /*
    * Accounts POST request --> creating DomainAdmin
    *
    * @param array $params
    * @param string $token
    */

    public function createUser(array $params, string $token){
        $this->token = $token;
        $params = [
            "username" => $params['username'],
            "password" => $params['password'],
            "perm_level" => "DomainAdmin",
            "api_access" => 1,
            "enabled" => 1,
            "recovery_email" => strtolower( $params['clientsdetails']['email'] ),
            "language" => "en",
            "domains" => '',
            "storagequota_total" => (int)$params['configoption1'],
            "quota_domains" => (int)$params['configoption2'],
            "quota_mailboxes" => (int)$params['configoption3'],
            "quota_aliases" => (int)$params['configoption4'],
            "quota_domainaliases" => (int)$params['configoption5'],
        ];
        $request = $this->request( 'post', '/api/v1/accounts/',$params );
        return $request;
    }

    /*
    * Account DomainAdmin cascade  enable PATCH request
    *
    * @param string $username
    * @param string $token
    */

    public function enableUser(string $username, string $token){
        $this->token = $token;
        $request = $this->request( 'patch', '/api/v1/accounts/cascade/domainadmin/' . $username . '/enable/',[] );
        return $request;
    }


    /*
    * Account DomainAdmin cascade disable  PATCH request
    *
    * @param string $username
    * @param string $token
    */


    public function disableUser(string $username, string $token){
        $this->token = $token;
        $request = $this->request( 'patch', '/api/v1/accounts/cascade/domainadmin/' . $username . '/disable/',[] );
        return $request;
    }

    /*
    * Account DomainAdmin cascade delete DELETE request
    *
    * @param string $username
    * @param string $token
    */

    public function deleteUser(string $username, string $token){
        $this->token = $token;
        $request = $this->request( 'delete', '/api/v1/accounts/cascade/domainadmin/' . $username . '/',[] );
        return $request;
    }


}
